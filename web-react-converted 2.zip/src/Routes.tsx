import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import App from '@app/app/App'
import Page from '@app/app/shared/components/page/Page'
import Table from '@app/app/shared/components/table/Table'
import Header from '@app/app/shared/components/header/Header'
import SessionTimeoutDialog from '@app/app/sso/component/session-timeout-dialog/SessionTimeoutDialog'
import NotFound from '@app/app/sso/component/not-found/NotFound'
import Logout from '@app/app/sso/component/logout/Logout'
import HealthCheck from '@app/app/sso/component/health-check/HealthCheck'
import PingPe from '@app/app/sso/component/ping-pe/PingPe'
import VerticalForm from '@app/app/portfolio-mgmt/component/portfolio-editor/vertical-form/VerticalForm'
import EditorTab from '@app/app/portfolio-mgmt/component/portfolio-editor/editor-tab/EditorTab'
import Accumulators from '@app/app/portfolio-mgmt/component/portfolio-editor/accumulators/Accumulators'
import MyPlans from '@app/app/portfolio-mgmt/component/my-plans/MyPlans'
import PortfolioManagement from '@app/app/portfolio-mgmt/component/portfolio-management/PortfolioManagement'

export default function Routes(){
  return (
    <Routes>
      <Route path='/app' element={<App />} />
      <Route path='/page' element={<Page />} />
      <Route path='/table' element={<Table />} />
      <Route path='/header' element={<Header />} />
      <Route path='/sessiontimeoutdialog' element={<SessionTimeoutDialog />} />
      <Route path='/notfound' element={<NotFound />} />
      <Route path='/logout' element={<Logout />} />
      <Route path='/healthcheck' element={<HealthCheck />} />
      <Route path='/pingpe' element={<PingPe />} />
      <Route path='/verticalform' element={<VerticalForm />} />
      <Route path='/editortab' element={<EditorTab />} />
      <Route path='/accumulators' element={<Accumulators />} />
      <Route path='/myplans' element={<MyPlans />} />
      <Route path='/portfoliomanagement' element={<PortfolioManagement />} />
      <Route path='*' element={<Navigate to='/App' replace />} />
    </Routes>
  )
}