import React from 'react';

// Auto-converted from src/app/sso/component/ping-pe/ping-pe.component.ts
export default function PingPe() {
  return (
    <>

    </>
  )
}
