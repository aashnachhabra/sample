import React from 'react';

// Auto-converted from src/app/sso/component/logout/logout.component.ts
export default function Logout() {
  return (
    <>
      <div className="modal-overlay">
          <div className="modal-container">
            <div className="modal-content">
              <h1 className="modal-title">Session Expired</h1>
              <p className="modal-message">Your session has expired due to inactivity.</p>
              <button type="button" className="modal-button" onClick={() => { /* login() */ }}>SSO Login</button>
            </div>
          </div>
        </div>
    </>
  )
}
