import React from 'react';

// Auto-converted from src/app/sso/component/session-timeout-dialog/session-timeout-dialog.component.ts
export default function SessionTimeoutDialog() {
  return (
    <>
      <p-dialog header="Session Timeout" [(visible)]="display" \1={\2} \1={\2}>
          <p>Session has expired. Please log in again.</p>
      
          Dialog will close in {\1} seconds.
          <br/>
          <br/>
          <div className="p-dialog-footer">
              <button type="button" pButton icon="pi pi-check" onClick={() => { /* continueSession() */ }} label="Continue"></button>
          </div>
      </p-dialog>
    </>
  )
}
