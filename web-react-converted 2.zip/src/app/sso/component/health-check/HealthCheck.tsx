import React from 'react';

// Auto-converted from src/app/sso/component/health-check/health-check.component.ts
export default function HealthCheck() {
  return (
    <>
      <p>Application is running</p>
    </>
  )
}
