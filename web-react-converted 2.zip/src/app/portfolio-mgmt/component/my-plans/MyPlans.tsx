import React from 'react';

// Auto-converted from src/app/portfolio-mgmt/component/my-plans/my-plans.component.ts
export default function MyPlans() {
  return (
    <>
      <div className="p-card-body">
        <!-- View Switcher Buttons -->
        <div className="p-mb-3">
          <p-button
            label="DBS ID"
            \1={\2}
            \1={\2}
            onClick={() => { /* switchView('dbsId') */ }}
            className="p-mr-2">
          </p-button>
          <p-button
            label="Member Group"
            \1={\2}
            \1={\2}
            onClick={() => { /* switchView('memberGroup') */ }}>
          </p-button>
        </div>
      
        <!-- DBS ID Table with Accordion -->
        <div data-ngif="dbsIdSelected" className="p-3">
          <portfolio-editor-table
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            (pageChange)="onPageChange($event)">
          </portfolio-editor-table>
        </div>
      
        <!-- Member Group Table with Accordion -->
        <div data-ngif="!dbsIdSelected" className="p-3">
          <portfolio-editor-table
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            \1={\2}
            (pageChange)="onPageChange($event)"
            (rowExpand)="onRowExpand($event)"
            (rowCollapse)="onRowCollapse($event)">
          </portfolio-editor-table>
        </div>
      </div>
    </>
  )
}
