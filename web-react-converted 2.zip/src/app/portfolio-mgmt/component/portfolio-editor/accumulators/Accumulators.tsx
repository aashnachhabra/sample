import React from 'react';

// Auto-converted from src/app/portfolio-mgmt/component/portfolio-editor/accumulators/accumulators.component.ts
export default function Accumulators() {
  return (
    <>
      <p-accordion \1={\2} className="w-full h-full ">
        <p-accordionTab header="Accumulators" \1={\2}>
          <div className="flex flex-col w-full h-full">
            <div className="flex-1 overflow-auto">
      
              <p-table \1={\2} \1={\2} scrollHeight="800px">
                <ng-template pTemplate="header">
                  <tr className="border-round">
                    <th></th>
                    <th className="bg-custom">Preferred</th>
                    <th className="bg-custom">Network</th>
                    @if (isMedical) {
                      <th className="bg-custom">OON</th>
                    }
                  </tr>
                </ng-template>
                <ng-template pTemplate="body" let-row>
                  <tr>
                    <td className="p-1">{\1}</td>
                    @if (row.isDropdown) {
                    <td colspan="3" className="p-1">
                      <p-dropdown \1={\2} data-ngmodel="\1" optionLabel="name" />
                    </td>
                    }  @else if (!row.isDropdown && isMedical) {
                      <td className="p-1"> <input pInputText className="w-full" /></td>
                      <td className="p-1"> <input pInputText className="w-full" /></td>
                      <td className="p-1"> <input pInputText className="w-full" /></td>
                      } @else if (!row.isDropdown && !isMedical) {
                    <td className="p-1"> <input pInputText className="w-full" /></td>
                    <td className="p-1"> <input pInputText className="w-full" /></td>
                    }
                  </tr>
                </ng-template>
              </p-table>
            </div>
          </div>
        </p-accordionTab>
      </p-accordion>
    </>
  )
}
