import React from 'react';

// Auto-converted from src/app/portfolio-mgmt/component/portfolio-editor/editor-tab/editor-tab.component.ts
export default function EditorTab() {
  return (
    <>
      <p-tabView className="w-full h-fit">
          <p-tabPanel header="Header 1">
              <ng-template pTemplate="header"><button pButton onClick={() => { /* handleCurrentTabChange(0) */ }}
                      \1={\2}><i className="pi pi-folder"></i>Medical</button></ng-template>
              <!-- Insert medical details component here -->
              <app-accumulators />
              <p-accordion>
                  <p-accordionTab header="Medical Benefits">
                      @for( title of benefitCategoryTitles; track title ){ <app-benefit-category
                          \1={\2} />}
                  </p-accordionTab>
              </p-accordion>
          </p-tabPanel>
          <p-tabPanel header="Header 2">
              <ng-template pTemplate="header"><button pButton onClick={() => { /* handleCurrentTabChange(1) */ }}
                      \1={\2}><i className="pi pi-book"></i>Pharmacy</button></ng-template>
              <!-- Insert Pharmacy componenet here -->
              <app-accumulators \1={\2} />
              <p-accordion>
                  <p-accordionTab header="Pharmacy Benefits">
              @for( title of benefitCategoryTitles; track title ){ <app-benefit-category \1={\2} />}
                  </p-accordionTab>
              </p-accordion>
      
          </p-tabPanel>
          <p-tabPanel header="Header 3" \1={\2}>
              <ng-template pTemplate="header"><button pButton \1={\2} \1={\2}><i
                          className="pi pi-folder-plus"></i>Riders</button></ng-template>
              <!-- Insert Riders component here -->
          </p-tabPanel>
          <p-tabPanel header="Header 4" \1={\2}>
              <ng-template pTemplate="header"><button pButton \1={\2} \1={\2}><i
                          className="pi pi-file"></i>Member Group Details</button></ng-template>
              <!-- Insert Member Group Details component here -->
          </p-tabPanel>
          <p-tabPanel header="Header 5" \1={\2}>
              <ng-template pTemplate="header"><button pButton \1={\2} \1={\2}><i
                          className="pi pi-comments"></i>Comments</button></ng-template>
              <!-- Insert Comments and changelogs component here -->
          </p-tabPanel>
          <p-tabPanel header="Header 6" \1={\2}>
              <ng-template pTemplate="header"><button pButton \1={\2} \1={\2}><i
                          className="pi pi-history"></i>Change Logs</button></ng-template>
              <!-- Insert Comments and changelogs component here -->
          </p-tabPanel>
      </p-tabView>
    </>
  )
}
