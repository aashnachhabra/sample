import React from 'react';

// Auto-converted from src/app/portfolio-mgmt/component/portfolio-management/portfolio-management.component.ts
export default function PortfolioManagement() {
  return (
    <>
      <div>
        <p-tabView>
          <p-tabPanel header="Portfolio Management" \1={\2}>
            <h1>Portfolio Management</h1>
            <div className="p-card p-3 m-5">
      
              <div className="p-card-body">
                <form \1={\2} (ngSubmit)="onSearch()">
                  <div className="grid">
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <input id="planCode" type="text" pInputText formControlName="planCode" className="w-full" />
                        <label for="planCode">Plan Code</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="segment" formControlName="segment" \1={\2} optionLabel="label"
                          optionValue="value" \1={\2} className="w-full"
                          \1={\2}>
                        </p-dropdown>
                        <label for="segment" \1={\2}>Segment</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="state" formControlName="state" \1={\2} optionLabel="label"
                          optionValue="value" \1={\2} className="w-full"
                          \1={\2}>
                        </p-dropdown>
                        <label for="state" \1={\2}>State</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="cocSeries" formControlName="cocSeries" \1={\2}
                          optionLabel="label" optionValue="value" \1={\2} className="w-full"
                          \1={\2}>
                        </p-dropdown>
                        <label for="cocSeries" \1={\2}>COC
                          Series</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="license" formControlName="license" \1={\2} optionLabel="label"
                          optionValue="value" placeholder="Select License" className="w-full">
                        </p-dropdown>
                        <label for="license">License</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="product" formControlName="product" \1={\2} optionLabel="label"
                          optionValue="value" placeholder="Select Product" className="w-full">
                        </p-dropdown>
                        <label for="product">Product</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="standard" formControlName="standard" \1={\2} optionLabel="label"
                          optionValue="value" placeholder="Select Standard" className="w-full">
                        </p-dropdown>
                        <label for="standard">Standard</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="planType" formControlName="planType" \1={\2} optionLabel="label"
                          optionValue="value" placeholder="Select Plan Type" className="w-full">
                        </p-dropdown>
                        <label for="planType">Plan Type</label>
                      </div>
                    </div>
                  </div>
      
                  <div className="flex">
                    <button type="button" pButton label="Clear" size="small" \1={\2} severity="warning"
                      className="flex-1 flex align-items-center justify-content-center m-2" onClick={() => { /* onClear() */ }}>
                    </button>
                    <button type="submit" pButton label="Search" size="small" \1={\2}
                      className="flex-1 flex align-items-center justify-content-center m-2">
                    </button>
                  </div>
                </form>
      
                <div className="p-3">
                  <portfolio-editor-table \1={\2} \1={\2} \1={\2}
                    \1={\2} \1={\2} \1={\2} \1={\2}
                    \1={\2} \1={\2} \1={\2} \1={\2}
                    (pageChange)="onPageChange($event)">
                  </portfolio-editor-table>
                </div>
              </div>
      
              <p-toast \1={\2} position="bottom-right"></p-toast>
            </div>
          </p-tabPanel>
          <p-tabPanel header="My Plans">
            <h1>My Plans</h1>
            <div className="p-card p-3 m-5">
              <app-my-plans></app-my-plans>
            </div>
          </p-tabPanel>
        </p-tabView>
      </div>
    </>
  )
}
