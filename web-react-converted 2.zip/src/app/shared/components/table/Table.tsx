import React from 'react';

// Auto-converted from src/app/shared/components/table/table.component.ts
export default function Table() {
  return (
    <>
      <p-table
        #dt1
        dataKey="id"
        className="p-fluid"
        \1={\2}
        \1={\2}
        \1={\2}
        \1={\2}
        \1={\2}
        \1={\2}
        \1={\2}
        \1={\2}
        \1={\2}
        [(selection)]="selectedRecords"
        (selectionChange)="onSelectionChange($event)"
        (onPage)="onPageChange($event)"
        \1={\2}
      >
        <ng-template pTemplate="caption">
          <div className="flex mt-3 justify-content-between px-0">
            <div className="flex">
              <p-button
                data-ngfor="let action of actions"
                label="{\1}"
                icon="{\1}"
                \1={\2}
                (onClick)="actionClick({}, action.func, action.params)"
              ></p-button>
            </div>
            <div className="flex flex-column align-items-center">
              <div data-ngif="enableGlobalFilter">
                <p-iconField iconPosition="left" className="ml-auto">
                  <p-inputIcon>
                    <i className="pi pi-search"></i>
                  </p-inputIcon>
                  <input
                    data-ngif="enableServerSideFilter"
                    pInputText
                    type="text"
                    placeholder="Search keyword"
                    (input)="triggerSearch($any($event).target.value)"
                  />
                  <input
                    data-ngif="!enableServerSideFilter"
                    pInputText
                    type="text"
                    (input)="dt1.filterGlobal($any($event).target.value, 'contains')"
                    placeholder="Search keyword"
                  />
                </p-iconField>
              </div>
              <div data-ngif="enableShowDeactivatedToggle" className="mt-3">
                <p-checkbox
                  inputId="ny"
                  data-ngmodel="\1"
                  (ngModelChange)="onShowDeactivatedChange()"
                  \1={\2}
                />
                <label for="ny" className="ml-2 cursor-pointer">Show Deactivated</label>
              </div>
            </div>
          </div>
        </ng-template>
        <ng-template pTemplate="header" let-columns>
          <tr>
            <!-- Expand/Collapse column for accordion -->
            <th data-ngif="settings.expandable" style="width: 4rem">
              <i data-ngif="settings.expandableHeader" className="pi pi-chevron-right"></i>
            </th>
            <th data-ngif="settings.selectable" style="width: 4rem">
              <p-tableHeaderCheckbox></p-tableHeaderCheckbox>
            </th>
            <th
              data-ngfor="let col of columns"
              \1={\2}
              \1={\2}
              [style.width]="col.width || 'auto'"
              [style.min-width]="col.minWidth || 'auto'"
              [style.max-width]="col.maxWidth || 'auto'"
            >
              {\1}
              <p-sortIcon data-ngif="enableSort" field="{\1}" />
              <p-columnFilter
                type="text"
                field="{\1}"
                ariaLabel="Filter {\1}"
                display="menu"
                data-ngif="col.showFilter"
              />
            </th>
            <!-- Fixed action header -->
            <th data-ngif="settings.actions" className="actions-column-header">
              <div className="actions-header-content">Action</div>
            </th>
          </tr>
        </ng-template>
        <ng-template pTemplate="body" let-rowData let-columns="columns" let-rowIndex="rowIndex">
          <!-- Parent Row -->
          <tr \1={\2} \1={\2}>
            <!-- Expand/Collapse toggle -->
            <td data-ngif="settings.expandable" style="width: 4rem; text-align: left;">
              <button
                data-ngif="hasChildren(rowData)"
                type="button"
                pButton
                className="p-button-text p-button-sm accordion-toggle"
                \1={\2}
                onClick={() => { /* toggleExpand(rowData) */ }}
              ></button>
            </td>
      
            <td data-ngif="settings.selectable">
              <p-tableCheckbox
                \1={\2}
                \1={\2}
              ></p-tableCheckbox>
            </td>
      
            <ng-container data-ngfor="let col of columns">
              <td [style.width]="col.width || 'auto'" [style.min-width]="col.minWidth || 'auto'">
                <p-skeleton data-ngif="loading" />
                <div data-ngif="records && !loading">
                  <!-- display for simple string value -->
                  <div data-ngif="!col.collapsibleRow">
                    {\1}
                  </div>
                  <!-- collapsible display for multiple line value like json format value -->
                  <button
                    type="button"
                    className="collapse-btn"
                    pButton
                    icon="pi pi-angle-right"
                    onClick={() => { /* toggleCollapse(rowData) */ }}
                    data-ngif="
                      col.collapsibleRow &&
                      !rowData.collapsed &&
                      (col.transform
                        ? col.transform(rowData[col.field])
                        : rowData[col.field]) != null
                    "
                  ></button>
                  <div
                    className="value-container"
                    onClick={() => { /* toggleCollapse(rowData) */ }}
                    data-ngif="col.collapsibleRow && rowData.collapsed"
                  >
                    {\1}
                  </div>
                </div>
              </td>
            </ng-container>
      
            <!-- Fixed action field -->
            <td data-ngif="settings.actions" className="actions-column-cell">
              <div className="actions-cell-content">
                <p-buttonGroup>
                  <ng-container data-ngfor="let action of settings.actions">
                    <p-button
                      data-ngif="!action.showWhen || action.showWhen(rowData)"
                      icon="{\1}"
                      \1={\2}
                      \1={\2}
                      \1={\2}
                      \1={\2}
                      (onClick)="actionClick(rowData, action.func, action.params)"
                      pTooltip="{\1}"
                      tooltipPosition="left"
                    >
                    </p-button>
                  </ng-container>
                </p-buttonGroup>
              </div>
            </td>
          </tr>
      
          <!-- Child Table Row (Expanded Content) -->
          <tr data-ngif="settings.expandable && rowData.expanded && hasChildren(rowData)" className="child-table-row">
            <td [attr.colspan]="(settings.expandable ? 1 : 0) + (settings.selectable ? 1 : 0) + columnMaps.length + (settings.actions ? 1 : 0)">
              <div className="child-table-container">
                <!-- Render child table -->
                <portfolio-editor-table
                  data-ngif="settings.childTableSettings"
                  \1={\2}
                  \1={\2}
                  \1={\2}
                  \1={\2}
                  \1={\2}
                  \1={\2}
                  \1={\2}
                  \1={\2}
                  \1={\2}
                ></portfolio-editor-table>
      
                <!-- Alternative: Simple child data display if no child table settings -->
                <div data-ngif="!settings.childTableSettings" className="simple-child-display">
                  <div data-ngfor="let child of rowData.children" className="child-item p-2 border-bottom-1">
                    {\1}
                  </div>
                </div>
              </div>
            </td>
          </tr>
        </ng-template>
        <ng-template pTemplate="emptymessage">
          <tr>
            <td colspan="100%" className="text-center">{\1}</td>
          </tr>
        </ng-template>
      </p-table>
      
      <p-paginator
        (onPageChange)="onPageChange($event)"
        \1={\2}
        \1={\2}
        \1={\2}
        \1={\2}
      />
    </>
  )
}
