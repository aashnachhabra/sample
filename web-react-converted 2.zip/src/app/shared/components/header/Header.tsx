import React from 'react';

// Auto-converted from src/app/shared/components/header/header.component.ts
export default function Header() {
  return (
    <>
      <nav className="flex justify-content-start bg-primary py-2 px-3">
        <div className="p-fluid">
          <a href="#">
            <img
              src="../../../../assets/images/UHC_Lockup_wht_RGB.png"
              alt="UHC Logo"
              className="img-fluid"
              width="150"
              height="50"
            />
          </a>
        </div>
      </nav>
    </>
  )
}
