import React from 'react';

// Auto-converted from src/app/app.component.ts
export default function App() {
  return (
    <>
      <lex-portfolio-editor-header/>
      <router-outlet/>
    </>
  )
}
