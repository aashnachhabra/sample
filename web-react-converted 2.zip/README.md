Converted project. Run npm install && npm run dev
Alias @app -> src/app is configured in vite.config.ts