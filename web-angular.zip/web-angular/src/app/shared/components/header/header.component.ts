import { Component } from '@angular/core';

@Component({
  selector: 'lex-portfolio-editor-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  launchModalTimeZone() {
  }

  openNotifModal(title: string, type: string, status?: string) {
  }
}
