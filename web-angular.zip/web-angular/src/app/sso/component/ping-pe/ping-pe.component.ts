import { Component } from '@angular/core';

@Component({
  selector: 'ping-pe',
  template: ''
})
export class PingPEComponent {

}
