import React from 'react'

// Auto-converted from src/app/portfolio-mgmt/component/portfolio-management/portfolio-management.component.ts
// NOTE: Review event handlers, two-way bindings, and any Angular-specific directives.
// Styling preserved by keeping className and CSS files.
export default function PortfolioManagement() {
  return (
    <>
      <div>
        <p-tabView>
          <p-tabPanel header="Portfolio Management" selected={true}>
            <h1>Portfolio Management</h1>
            <div className="p-card p-3 m-5">

              <div className="p-card-body">
                <form formGroup={searchForm} (ngSubmit)="onSearch()">
                  <div className="grid">
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <input id="planCode" type="text" pInputText formControlName="planCode" className="w-full" />
                        <label for="planCode">Plan Code</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="segment" formControlName="segment" options={segmentOptions} optionLabel="label"
                          optionValue="value" placeholder={' '} className="w-full"
                          className={'has-value': searchForm.get('segment')?.value}>
                        </p-dropdown>
                        <label for="segment" className={'label-float': searchForm.get('segment')?.value}>Segment</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="state" formControlName="state" options={stateOptions} optionLabel="label"
                          optionValue="value" placeholder={' '} className="w-full"
                          className={'has-value': searchForm.get('state')?.value}>
                        </p-dropdown>
                        <label for="state" className={'label-float': searchForm.get('state')?.value}>State</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="cocSeries" formControlName="cocSeries" options={cocSeriesOptions}
                          optionLabel="label" optionValue="value" placeholder={' '} className="w-full"
                          className={'has-value': searchForm.get('cocSeries')?.value}>
                        </p-dropdown>
                        <label for="cocSeries" className={'label-float': searchForm.get('cocSeries')?.value}>COC
                          Series</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="license" formControlName="license" options={licenseOptions} optionLabel="label"
                          optionValue="value" placeholder="Select License" className="w-full">
                        </p-dropdown>
                        <label for="license">License</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="product" formControlName="product" options={productOptions} optionLabel="label"
                          optionValue="value" placeholder="Select Product" className="w-full">
                        </p-dropdown>
                        <label for="product">Product</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="standard" formControlName="standard" options={standardOptions} optionLabel="label"
                          optionValue="value" placeholder="Select Standard" className="w-full">
                        </p-dropdown>
                        <label for="standard">Standard</label>
                      </div>
                    </div>
                    <div className="flex justify-content-center col-3 p-2 mt-2">
                      <div className="p-float-label w-full">
                        <p-dropdown id="planType" formControlName="planType" options={planTypeOptions} optionLabel="label"
                          optionValue="value" placeholder="Select Plan Type" className="w-full">
                        </p-dropdown>
                        <label for="planType">Plan Type</label>
                      </div>
                    </div>
                  </div>

                  <div className="flex">
                    <button type="button" pButton label="Clear" size="small" outlined={true} severity="warning"
                      className="flex-1 flex align-items-center justify-content-center m-2" onClick={onClear}>
                    </button>
                    <button type="submit" pButton label="Search" size="small" outlined={true}
                      className="flex-1 flex align-items-center justify-content-center m-2">
                    </button>
                  </div>
                </form>

                <div className="p-3">
                  <portfolio-editor-table settings={tableSettings} records={tableData} loading={loading}
                    totalRecords={totalRecords} totalPages={totalPages} paginate={true} enableSort={true}
                    enableFilter={true} enableShowDeactivatedToggle={false} pageSize={25} rowsPerPage={[10, 25, 50]}
                    (pageChange)="onPageChange($event)">
                  </portfolio-editor-table>
                </div>
              </div>

              <p-toast life={5000} position="bottom-right"></p-toast>
            </div>
          </p-tabPanel>
          <p-tabPanel header="My Plans">
            <h1>My Plans</h1>
            <div className="p-card p-3 m-5">
              <app-my-plans></app-my-plans>
            </div>
          </p-tabPanel>
        </p-tabView>
      </div>
    </>
  )
}
