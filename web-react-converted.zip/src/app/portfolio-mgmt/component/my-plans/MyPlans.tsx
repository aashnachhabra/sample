import React from 'react'

// Auto-converted from src/app/portfolio-mgmt/component/my-plans/my-plans.component.ts
// NOTE: Review event handlers, two-way bindings, and any Angular-specific directives.
// Styling preserved by keeping className and CSS files.
export default function MyPlans() {
  return (
    <>
      <div className="p-card-body">
        <!-- View Switcher Buttons -->
        <div className="p-mb-3">
          <p-button
            label="DBS ID"
            severity={dbsIdSelected ? 'primary' : 'secondary'}
            outlined={!dbsIdSelected}
            onClick={switchView}
            className="p-mr-2">
          </p-button>
          <p-button
            label="Member Group"
            severity={!dbsIdSelected ? 'primary' : 'secondary'}
            outlined={dbsIdSelected}
            onClick={switchView}>
          </p-button>
        </div>

        <!-- DBS ID Table with Accordion -->
        <div data-ngif="dbsIdSelected" className="p-3">
          <portfolio-editor-table
            settings={mainTableSettings}
            records={mainTableData}
            loading={loading}
            totalRecords={totalRecords}
            totalPages={totalPages}
            paginate={true}
            enableSort={true}
            enableFilter={true}
            enableShowDeactivatedToggle={false}
            pageSize={25}
            rowsPerPage={[10, 25, 50]}
            (pageChange)="onPageChange($event)">
          </portfolio-editor-table>
        </div>

        <!-- Member Group Table with Accordion -->
        <div data-ngif="!dbsIdSelected" className="p-3">
          <portfolio-editor-table
            settings={memberGroupTableParentSettings}
            records={memberGroupTableData}
            loading={loading}
            totalRecords={memberGroupTotalRecords}
            totalPages={memberGroupTotalPages}
            paginate={true}
            enableSort={true}
            enableFilter={true}
            enableShowDeactivatedToggle={false}
            pageSize={25}
            rowsPerPage={[10, 25, 50]}
            (pageChange)="onPageChange($event)"
            (rowExpand)="onRowExpand($event)"
            (rowCollapse)="onRowCollapse($event)">
          </portfolio-editor-table>
        </div>
      </div>

    </>
  )
}
