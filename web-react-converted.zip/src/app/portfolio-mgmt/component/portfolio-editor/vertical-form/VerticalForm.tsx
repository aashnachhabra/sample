import React from 'react'

// Auto-converted from src/app/portfolio-mgmt/component/portfolio-editor/vertical-form/vertical-form.component.ts
// NOTE: Review event handlers, two-way bindings, and any Angular-specific directives.
// Styling preserved by keeping className and CSS files.
export default function VerticalForm() {
  return (
    <>
      <form className="form-bg flex flex-column align-items-center justify-content-start gap-2 w-27rem m-3 h-fit">
          <div className="w-full p-3 flex flex-column gap-2">
          <button pButton outlined={true} className="w-full p-button-flex gap-2"><i className="pi pi-save"></i>  Save</button>
          <button pButton outlined={true} severity="secondary" className="w-full" label="Close" onClick={redirectToHome}></button>
          </div>
    
          <p-divider className="w-full"></p-divider>

          <div className="bg-custom w-full text-center p-2">  
              <span className="text-xl font-medium">Plan Details</span>
          </div>
          <div className="w-full p-3 flex flex-column gap-2">
              @for(control of formControls; track control) {
                  <div className="flex flex-column gap-2 w-full">
                      <label for="username">{control['label']}</label>
                      <input pInputText />
                  </div>
              }
          </div>
      </form>
    </>
  )
}
