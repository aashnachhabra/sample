import React from 'react'

// Auto-converted from src/app/shared/components/page/page.component.ts
// NOTE: Review event handlers, two-way bindings, and any Angular-specific directives.
// Styling preserved by keeping className and CSS files.
export default function Page() {
  return (
    <>
      <div className="p-5 surface-ground h-screen">
        <div className="flex justify-content-between flex-wrap mb-4">
          <h1 className="my-0 text-primary">
            <i className="pi mr-2" className={icon} style="font-size: inherit"></i>
            {title }
          </h1>
        </div>

        <p-card>
          <ng-content></ng-content>
        </p-card>
      </div>

    </>
  )
}
