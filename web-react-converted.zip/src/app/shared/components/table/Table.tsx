import React from 'react'

// Auto-converted from src/app/shared/components/table/table.component.ts
// NOTE: Review event handlers, two-way bindings, and any Angular-specific directives.
// Styling preserved by keeping className and CSS files.
export default function Table() {
  return (
    <>
      <p-table
        #dt1
        dataKey="id"
        className="p-fluid"
        tableStyle={'min-width': '50rem' }
        columns={columnMaps}
        value={records}
        rows={pageSize}
        rowsPerPageOptions={rowsPerPage}
        showCurrentPageReport={true}
        currentPageReportTemplate={currentPageReportTemplate}
        globalFilterFields={globalFilters}
        selectionMode={settings.selectable ? 'multiple' : null}
        [(selection)]="selectedRecords"
        (selectionChange)="onSelectionChange($event)"
        (onPage)="onPageChange($event)"
        totalRecords={totalRecords}
      >
        <ng-template pTemplate="caption">
          <div className="flex mt-3 justify-content-between px-0">
            <div className="flex">
              <p-button
                data-ngfor="let action of actions"
                label="{action.title }"
                icon="{action.icon }"
                severity={action.severity}
                (onClick)="actionClick({}, action.func, action.params)"
              ></p-button>
            </div>
            <div className="flex flex-column align-items-center">
              <div data-ngif="enableGlobalFilter">
                <p-iconField iconPosition="left" className="ml-auto">
                  <p-inputIcon>
                    <i className="pi pi-search"></i>
                  </p-inputIcon>
                  <input
                    data-ngif="enableServerSideFilter"
                    pInputText
                    type="text"
                    placeholder="Search keyword"
                    (input)="triggerSearch($any($event).target.value)"
                  />
                  <input
                    data-ngif="!enableServerSideFilter"
                    pInputText
                    type="text"
                    (input)="dt1.filterGlobal($any($event).target.value, 'contains')"
                    placeholder="Search keyword"
                  />
                </p-iconField>
              </div>
              <div data-ngif="enableShowDeactivatedToggle" className="mt-3">
                <p-checkbox
                  inputId="ny"
                  data-ngmodel="showDeactivated"
                  (ngModelChange)="onShowDeactivatedChange()"
                  binary={true}
                />
                <label for="ny" className="ml-2 cursor-pointer">Show Deactivated</label>
              </div>
            </div>
          </div>
        </ng-template>
        <ng-template pTemplate="header" let-columns>
          <tr>
            <!-- Expand/Collapse column for accordion -->
            <th data-ngif="settings.expandable" style="width: 4rem">
              <i data-ngif="settings.expandableHeader" className="pi pi-chevron-right"></i>
            </th>
            <th data-ngif="settings.selectable" style="width: 4rem">
              <p-tableHeaderCheckbox></p-tableHeaderCheckbox>
            </th>
            <th
              data-ngfor="let col of columns"
              pSortableColumn={enableSort ? col.field : null}
              className={col.className}
              [style.width]="col.width || 'auto'"
              [style.min-width]="col.minWidth || 'auto'"
              [style.max-width]="col.maxWidth || 'auto'"
            >
              {col.header }
              <p-sortIcon data-ngif="enableSort" field="{col.field }" />
              <p-columnFilter
                type="text"
                field="{col.field }"
                ariaLabel="Filter {col.header }"
                display="menu"
                data-ngif="col.showFilter"
              />
            </th>
            <!-- Fixed action header -->
            <th data-ngif="settings.actions" className="actions-column-header">
              <div className="actions-header-content">Action</div>
            </th>
          </tr>
        </ng-template>
        <ng-template pTemplate="body" let-rowData let-columns="columns" let-rowIndex="rowIndex">
          <!-- Parent Row -->
          <tr pSelectableRow={rowData} className={'expandable-row': settings.expandable}>
            <!-- Expand/Collapse toggle -->
            <td data-ngif="settings.expandable" style="width: 4rem; text-align: left;">
              <button
                data-ngif="hasChildren(rowData)"
                type="button"
                pButton
                className="p-button-text p-button-sm accordion-toggle"
                icon={rowData.expanded ? 'pi pi-minus' : 'pi pi-plus'}
                onClick={toggleExpand}
              ></button>
            </td>

            <td data-ngif="settings.selectable">
              <p-tableCheckbox
                pSelectableRow={rowData}
                value={rowData}
              ></p-tableCheckbox>
            </td>

            <ng-container data-ngfor="let col of columns">
              <td [style.width]="col.width || 'auto'" [style.min-width]="col.minWidth || 'auto'">
                <p-skeleton data-ngif="loading" />
                <div data-ngif="records && !loading">
                  <!-- display for simple string value -->
                  <div data-ngif="!col.collapsibleRow">
                    {col.transform
                        ? col.transform(rowData[col.field])
                        : rowData[col.field]
                    }
                  </div>
                  <!-- collapsible display for multiple line value like json format value -->
                  <button
                    type="button"
                    className="collapse-btn"
                    pButton
                    icon="pi pi-angle-right"
                    onClick={toggleCollapse}
                    data-ngif="
                      col.collapsibleRow &&
                      !rowData.collapsed &&
                      (col.transform
                        ? col.transform(rowData[col.field])
                        : rowData[col.field]) != null
                    "
                  ></button>
                  <div
                    className="value-container"
                    onClick={toggleCollapse}
                    data-ngif="col.collapsibleRow && rowData.collapsed"
                  >
                    {col.transform
                        ? col.transform(rowData[col.field])
                        : rowData[col.field]
                    }
                  </div>
                </div>
              </td>
            </ng-container>

            <!-- Fixed action field -->
            <td data-ngif="settings.actions" className="actions-column-cell">
              <div className="actions-cell-content">
                <p-buttonGroup>
                  <ng-container data-ngfor="let action of settings.actions">
                    <p-button
                      data-ngif="!action.showWhen || action.showWhen(rowData)"
                      icon="{action.icon }"
                      label={action.showTitle ? action.title : undefined}
                      size={action.size}
                      severity={action.severity}
                      outlined={action.outlined}
                      (onClick)="actionClick(rowData, action.func, action.params)"
                      pTooltip="{action.title }"
                      tooltipPosition="left"
                    >
                    </p-button>
                  </ng-container>
                </p-buttonGroup>
              </div>
            </td>
          </tr>

          <!-- Child Table Row (Expanded Content) -->
          <tr data-ngif="settings.expandable && rowData.expanded && hasChildren(rowData)" className="child-table-row">
            <td [attr.colspan]="(settings.expandable ? 1 : 0) + (settings.selectable ? 1 : 0) + columnMaps.length + (settings.actions ? 1 : 0)">
              <div className="child-table-container">
                <!-- Render child table -->
                <portfolio-editor-table
                  data-ngif="settings.childTableSettings"
                  settings={settings.childTableSettings}
                  records={rowData.children}
                  loading={false}
                  enableSort={false}
                  enableFilter={false}
                  enableGlobalFilter={false}
                  enableShowDeactivatedToggle={false}
                  paginate={false}
                  emptyMessage={'No child records found'}
                ></portfolio-editor-table>

                <!-- Alternative: Simple child data display if no child table settings -->
                <div data-ngif="!settings.childTableSettings" className="simple-child-display">
                  <div data-ngfor="let child of rowData.children" className="child-item p-2 border-bottom-1">
                    {child | json }
                  </div>
                </div>
              </div>
            </td>
          </tr>
        </ng-template>
        <ng-template pTemplate="emptymessage">
          <tr>
            <td colspan="100%" className="text-center">{emptyMessage }</td>
          </tr>
        </ng-template>
      </p-table>

      <p-paginator
        (onPageChange)="onPageChange($event)"
        first={0}
        rows={pageSize}
        totalRecords={totalRecords}
        rowsPerPageOptions={rowsPerPage}
      />

    </>
  )
}
