import React from 'react'

// Auto-converted from src/app/sso/component/health-check/health-check.component.ts
// NOTE: Review event handlers, two-way bindings, and any Angular-specific directives.
// Styling preserved by keeping className and CSS files.
export default function HealthCheck() {
  return (
    <>
      <p>Application is running</p>
    </>
  )
}
