import React from 'react'

// Auto-converted from src/app/sso/component/not-found/not-found.component.ts
// NOTE: Review event handlers, two-way bindings, and any Angular-specific directives.
// Styling preserved by keeping className and CSS files.
export default function NotFound() {
  return (
    <>
      <div className="flex flex-column align-items-center justify-content-center h-screen">
          <div className="p-4">
              <div className="flex flex-column align-items-center gap-3">
                  <h1 className="text-3xl text-primary">404 - Page Not Found</h1>
                  <p className="text-lg text-secondary">Sorry, the page you are looking for does not exist.</p>
                  <div label="Go to Home" (onClick)="goToHome()" className="w-40"></div>
              </div>
          </div>
      </div>

    </>
  )
}
