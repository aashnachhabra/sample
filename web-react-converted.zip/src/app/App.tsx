import React from 'react'

// Auto-converted from src/app/app.component.ts
// NOTE: Review event handlers, two-way bindings, and any Angular-specific directives.
// Styling preserved by keeping className and CSS files.
export default function App() {
  return (
    <>
      <lex-portfolio-editor-header/>
      <router-outlet/>

    </>
  )
}
