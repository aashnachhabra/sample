import { Accordion, AccordionTab } from 'primereact/accordion';
import { Calendar } from 'primereact/calendar';
import { useMemo, useState } from 'react';

type Row = {
  label: string;
  options: string[];
  values: { tier1: string; inn: string; oon: string };
};

export function BenefitCategory({ title }: { title: string }) {
  const [effectiveFrom, setEffectiveFrom] = useState<Date | null>(null);
  const [effectiveTo, setEffectiveTo] = useState<Date | null>(null);
  const [activeTab, setActiveTab] = useState<'portfolio' | 'limits' | 'services' | 'history'>('portfolio');
  const [activeNav, setActiveNav] = useState<'info' | 'notes' | 'questions' | 'artifacts'>('info');

  const [rows, setRows] = useState<Row[]>(() => [
    { label: 'Levels', options: ['Low', 'Moderate', 'High'], values: { tier1: '', inn: '', oon: '' } },
    { label: 'Covered', options: ['Yes', 'No'], values: { tier1: '', inn: '', oon: '' } },
    { label: 'Copay', options: [], values: { tier1: '', inn: '', oon: '' } },
    { label: 'Copay Type', options: ['Per Day', 'Per occurence', 'Per Stay'], values: { tier1: '', inn: '', oon: '' } },
    { label: 'Max No.', options: [], values: { tier1: '', inn: '', oon: '' } },
    { label: 'Coinsurance', options: [], values: { tier1: '', inn: '', oon: '' } },
    { label: 'Deductable', options: ['Yes', 'No'], values: { tier1: '', inn: '', oon: '' } },
    { label: 'Per Occurance', options: ['Seldom', 'Moderate', 'Frequent'], values: { tier1: '', inn: '', oon: '' } },
    { label: 'Visits From', options: [], values: { tier1: '', inn: '', oon: '' } },
    { label: 'Visits Thru', options: [], values: { tier1: '', inn: '', oon: '' } }
  ]);

  const tabs = useMemo(() => [
    { label: 'Portfolio Information', key: 'portfolio' },
    { label: 'Limits and Codes Information', key: 'limits' },
    { label: 'Services Information', key: 'services' },
    { label: 'History Information', key: 'history' }
  ], []);

  return (
    <div className="w-full bg-white border border-slate-300 rounded-lg overflow-hidden">
      <Accordion multiple={false} className="w-full">
        <AccordionTab header={title}>
          <div className="p-6 space-y-6 text-slate-800">
            {/* Top Navigation */}
            <div className="flex flex-wrap justify-between items-start gap-6">
              {/* Effective Date */}
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium">Effective Date Between</label>
                <div className="flex gap-4 items-center">
                  <div className="flex flex-col gap-1">
                    <label className="text-xs text-slate-600">From</label>
                    <Calendar
                      value={effectiveFrom}
                      onChange={(e) => setEffectiveFrom(e.value as Date)}
                      dateFormat="mm/dd/yy"
                      placeholder="mm/dd/yyyy"
                      showIcon
                      className="w-40"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-xs text-slate-600">To</label>
                    <Calendar
                      value={effectiveTo}
                      onChange={(e) => setEffectiveTo(e.value as Date)}
                      dateFormat="mm/dd/yy"
                      placeholder="mm/dd/yyyy"
                      showIcon
                      className="w-40"
                    />
                  </div>
                </div>
              </div>

              {/* Nav Buttons */}
              <div className="flex gap-2 items-end">
                {[
                  { key: 'info', label: 'Information', icon: 'pi pi-book' },
                  { key: 'notes', label: 'Notes', icon: 'pi pi-comment-circle' },
                  { key: 'questions', label: 'Questions', icon: 'pi pi-question' },
                  { key: 'artifacts', label: 'Artifacts', icon: 'pi pi-book' }
                ].map((tab) => (
                  <button
                    key={tab.key}
                    className={`flex items-center gap-2 px-3 py-2 rounded-md border text-sm ${
                      activeNav === tab.key
                        ? 'bg-slate-100 border-slate-400 text-slate-800 font-semibold'
                        : 'bg-white border-slate-300 text-slate-600'
                    }`}
                    onClick={() => setActiveNav(tab.key)}
                  >
                    <i className={tab.icon}></i> {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-4 border-b border-slate-200 pb-2">
              {tabs.map((t) => (
                <button
                  key={t.key}
                  className={`text-sm px-3 py-1 rounded-t-md ${
                    activeTab === t.key
                      ? 'border-b-2 border-slate-500 text-slate-800 font-semibold'
                      : 'text-slate-500'
                  }`}
                  onClick={() => setActiveTab(t.key as any)}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* Portfolio Table */}
            {activeTab === 'portfolio' && (
              <div className="overflow-x-auto">
                <table className="min-w-full border border-slate-300 rounded-md text-sm">
                  <thead className="bg-slate-100 text-slate-700">
                    <tr>
                      <th className="px-4 py-2 text-left font-medium"></th>
                      <th className="px-4 py-2 text-left font-medium">Preferred Network (Tier 1)</th>
                      <th className="px-4 py-2 text-left font-medium">INN</th>
                      <th className="px-4 py-2 text-left font-medium">OON</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((row, rowIdx) => (
                      <tr key={rowIdx} className="border-t border-slate-200">
                        <td className={`px-4 py-2 ${row.label === 'Levels' ? 'font-semibold' : ''}`}>{row.label}</td>
                        {(['tier1', 'inn', 'oon'] as const).map((col) => (
                          <td key={col} className="px-4 py-2">
                            {row.options.length ? (
                              <select
                                value={row.values[col]}
                                onChange={(e) => {
                                  const v = e.target.value;
                                  setRows((prev) =>
                                    prev.map((r, idx) =>
                                      idx === rowIdx ? { ...r, values: { ...r.values, [col]: v } } : r
                                    )
                                  );
                                }}
                                className="w-full border border-slate-300 rounded-md px-2 py-1 text-sm"
                              >
                                <option value="">Select</option>
                                {row.options.map((opt) => (
                                  <option key={opt} value={opt}>
                                    {opt}
                                  </option>
                                ))}
                              </select>
                            ) : (
                              <input
                                type="text"
                                className="w-full border border-slate-300 rounded-md px-2 py-1 text-sm"
                                value={row.values[col]}
                                onChange={(e) => {
                                  const v = e.target.value;
                                  setRows((prev) =>
                                    prev.map((r, idx) =>
                                      idx === rowIdx ? { ...r, values: { ...r.values, [col]: v } } : r
                                    )
                                  );
                                }}
                              />
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </AccordionTab>
      </Accordion>
    </div>
  );
}
