import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';

const BRAND = '#002677';

export function VerticalForm() {
  const navigate = useNavigate();

  const controls = useMemo(
    () => [
      { label: 'Plan Code', name: 'PlanCode' },
      { label: 'Plan Type', name: 'PlanType' },
      { label: 'COC Series', name: 'COCSeries' },
      { label: 'Organization', name: 'Organization' },
      { label: 'State', name: 'State' },
      { label: 'Segment', name: 'Segment' },
      { label: 'Legal Entity', name: 'LegalEntity' },
      { label: 'Product Type', name: 'ProductType' },
      { label: 'Product', name: 'Product' },
      { label: 'Standard', name: 'Standard' },
      { label: 'HSA Eligible', name: 'HSAEligible' },
      { label: 'Gated Product', name: 'GatedProduct' },
      { label: 'Case Effective', name: 'CaseEffective' },
      { label: 'Deductible Period', name: 'DeductiblePeriod' },
      { label: 'Grandfathered', name: 'Grandfathered' },
      { label: 'Transitional', name: 'Transitional' },
      { label: 'Plan Category', name: 'PlanCategory' },
      { label: 'Description', name: 'Description' },
      { label: 'Previous marketing name', name: 'PreviousMarketingName' },
      { label: 'Current Marketing Name', name: 'CurrentMarketingName' },
      { label: 'Alternate Description', name: 'AlternateDescription' },
      { label: 'MSK Low Back', name: 'MSKLowBack' },
      { label: 'Visit Limits Combined', name: 'VisitLimitsCombined' },
      { label: 'Previous HIOS Plan ID', name: 'PreviousHIOSPlanID' },
      { label: 'Current HIOS Plan ID', name: 'CurrentHIOSPlanID' },
      { label: 'Metallic Level', name: 'MetallicLevel' },
      { label: 'Actuarial Level', name: 'ActuarialLevel' },
      { label: 'AV Calculator', name: 'AVCalculator' },
      { label: 'Available Country', name: 'AvailableCountry' },
      { label: 'Actuarial Value Min', name: 'ActuarialValueMin' },
      { label: 'Actuarial Value Max', name: 'ActuarialValueMax' },
      { label: 'Rule Package Key', name: 'RulePackageKey' }
    ],
    []
  );

  const [values, setValues] = useState<Record<string, string>>({});

  const fullRowLabels = new Set([
    'Description',
    'Alternate Description',
    'Previous marketing name',
    'Current Marketing Name'
  ]);

  const onChange =
    (name: string) =>
    (e: React.ChangeEvent<HTMLInputElement>) => {
      setValues((prev) => ({ ...prev, [name]: e.target.value }));
    };

  return (
    <div className="w-full min-h-screen bg-white p-6">
      <div className="border border-slate-300 rounded-lg overflow-hidden">
        {/* Top buttons */}
        <div className="w-full px-6 pt-6 bg-slate-50 border-b border-slate-300">
          <div className="grid grid-cols-1 gap-3">
            <Button
              type="button"
              label="Save"
              icon="pi pi-save"
              iconPos="left"
              outlined
              className="w-full !h-12 !rounded-lg !text-[15px] !font-semibold !shadow-none
                         !bg-white !text-[#002677] !border-2 !border-[#002677]
                         hover:!bg-[#002677]/5 !justify-start !px-4"
              onClick={() => console.log('Save clicked', values)}
            />
            <Button
              type="button"
              label="Close"
              icon="pi pi-times"
              iconPos="left"
              outlined
              className="w-full !h-12 !rounded-lg !text-[15px] !font-semibold !shadow-none
                         !bg-white !text-[#002677] !border-2 !border-[#002677]
                         hover:!bg-[#002677]/5 !justify-start !px-4"
              onClick={() => navigate('/portfolio-management')}
            />
          </div>
        </div>

        {/* Title */}
        <div className="w-full px-6 py-4 border-b border-slate-300 bg-white">
          <h1 className="text-xl sm:text-2xl font-semibold text-slate-800">Plan Details</h1>
        </div>

        {/* Form */}
        <form className="w-full px-6 py-6 bg-white">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {controls.map((c) => (
              <div
                key={c.name}
                className={`w-full ${fullRowLabels.has(c.label)
                  ? 'md:col-span-2 lg:col-span-3 xl:col-span-4'
                  : ''}`}
              >
                <label
                  htmlFor={c.name}
                  className="block text-[12px] font-semibold text-slate-700 tracking-wide mb-1.5"
                >
                  {c.label}
                </label>
                <InputText
                  id={c.name}
                  value={values[c.name] || ''}
                  onChange={onChange(c.name)}
                  placeholder={c.label}
                  className="w-full h-12 rounded-lg border border-slate-300 bg-white px-4 text-[15px] text-slate-900
                             placeholder:text-slate-400 shadow-sm
                             focus:border-[#002677] focus:ring-2 focus:ring-[#002677]/30"
                />
              </div>
            ))}
          </div>
        </form>
      </div>
    </div>
  );
}
