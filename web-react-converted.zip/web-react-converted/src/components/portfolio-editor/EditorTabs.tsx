import { TabView, TabPanel } from 'primereact/tabview';
import { Accumulators } from './Accumulators';
import { BenefitCategory } from './BenefitCategory';

export function EditorTabs() {
  const titles = [
    'Ambulance Services - Emergency',
    'Ambulance Services - Non-Emergency',
    'Dental Services - Accident Only'
  ];

  return (
    <div className="w-full bg-white border border-slate-300 rounded-lg overflow-hidden">
      <TabView className="w-full">
        {/* Medical Tab */}
        <TabPanel header="Medical" leftIcon="pi pi-folder mr-2">
          <div className="space-y-6">
            <Accumulators isMedical />
            <div className="border border-slate-200 rounded-md">
              <div className="bg-slate-100 px-4 py-2 text-slate-700 font-semibold border-b border-slate-300">
                Medical Benefits
              </div>
              <div className="p-4 space-y-4">
                {titles.map((t) => (
                  <BenefitCategory key={t} title={t} />
                ))}
              </div>
            </div>
          </div>
        </TabPanel>

        {/* Pharmacy Tab */}
        <TabPanel header="Pharmacy" leftIcon="pi pi-book mr-2">
          <div className="space-y-6">
            <Accumulators isMedical={false} />
            <div className="border border-slate-200 rounded-md">
              <div className="bg-slate-100 px-4 py-2 text-slate-700 font-semibold border-b border-slate-300">
                Pharmacy Benefits
              </div>
              <div className="p-4 space-y-4">
                {titles.map((t) => (
                  <BenefitCategory key={t} title={t} />
                ))}
              </div>
            </div>
          </div>
        </TabPanel>

        {/* Disabled Tabs */}
        <TabPanel header="Riders" disabled leftIcon="pi pi-folder-plus mr-2" />
        <TabPanel header="Member Group Details" disabled leftIcon="pi pi-file mr-2" />
        <TabPanel header="Comments" disabled leftIcon="pi pi-comments mr-2" />
        <TabPanel header="Change Logs" disabled leftIcon="pi pi-history mr-2" />
      </TabView>
    </div>
  );
}
