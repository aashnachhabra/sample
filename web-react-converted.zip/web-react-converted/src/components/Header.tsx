export function Header() {
  return (
    <nav className="app-header">
      <div className="p-fluid">
        <a href="#">
          <img src="/assets/images/UHC_Lockup_wht_RGB.png" alt="UHC Logo" />
        </a>
      </div>
    </nav>
  );
}


