import { useMemo, useState } from 'react';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { TabView, TabPanel } from 'primereact/tabview';
import { Table, TableSettings, ActionSettings } from '@/components/Table';
import { useNavigate } from 'react-router-dom';
import { Icon } from '@iconify/react';

const BRAND = '#002677';

type SearchState = {
  planCode: string;
  segment: string;
  state: string;
  cocSeries: string;
  license: string;
  product: string;
  standard: string;
  planType: string;
};

const DEFAULT_SEARCH: SearchState = {
  planCode: '',
  segment: '',
  state: '',
  cocSeries: '',
  license: '',
  product: '',
  standard: '',
  planType: ''
};

export function PortfolioManagement() {
  const navigate = useNavigate();
  const [search, setSearch] = useState<SearchState>(DEFAULT_SEARCH);

  const tableData = useMemo(
    () => [
      { planCode: 'PC001', orgnaization: 'Org A', cocSeries: 'COC-A', state: 'CA', segment: 'KA', license: 'LIC001', product: 'Product-A', standard: 'Standard' },
      { planCode: 'PC002', orgnaization: 'Org A', cocSeries: 'COC-B', state: 'TX', segment: 'KA', license: 'LIC002', product: 'Product-A', standard: 'Standard' },
      { planCode: 'PC003', orgnaization: 'Org A', cocSeries: 'COC-C', state: 'NY', segment: 'KA', license: 'LIC003', product: 'Product-A', standard: 'Standard' }
    ],
    []
  );

  // Style action buttons so they look like real buttons in the Actions column
  const actions: ActionSettings[] = [
    {
      title: 'Standard',
      showTitle: true,
      func: () => navigate('/portfolio-management/portfolio-editor'),
      params: [],
      size: 'small',
      outlined: false,
      severity: 'primary',
      className:
        '!rounded-md !h-9 !px-3 !text-[13px] !bg-[#002677] !border-[#002677] !text-white hover:!bg-[#001d59]'
    },
    {
      title: 'Custom',
      showTitle: true,
      func: () => navigate('/portfolio-management/portfolio-editor'),
      params: [],
      size: 'small',
      outlined: false,
      severity: 'primary',
      className:
        '!rounded-md !h-9 !px-3 !text-[13px] !bg-[#002677] !border-[#002677] !text-white hover:!bg-[#001d59]'
    }
  ];

  const tableSettings: TableSettings = {
    columns: [
      { field: 'planCode', header: 'Plan Code', width: '160px', minWidth: '140px' },
      { field: 'cocSeries', header: 'COC Series', width: '180px', minWidth: '160px' },
      { field: 'state', header: 'State', width: '120px', minWidth: '100px' },
      { field: 'segment', header: 'Segment', width: '140px', minWidth: '120px' },
      { field: 'license', header: 'License', width: '180px', minWidth: '160px' },
      { field: 'product', header: 'Published', width: '180px', minWidth: '160px' },
      { field: 'standard', header: 'Standard', width: '160px', minWidth: '140px' }
    ],
    actions,
    selectable: false
  };

  const FILTERS: Array<{ id: keyof SearchState; label: string; options: string[] }> = [
    { id: 'segment', label: 'Segment', options: ['KA', 'KB', 'KC'] },
    { id: 'state', label: 'State', options: ['CA', 'TX', 'NY', 'FL'] },
    { id: 'cocSeries', label: 'COC Series', options: ['COC-A', 'COC-B', 'COC-C'] },
    { id: 'license', label: 'License', options: ['LIC001', 'LIC002', 'LIC003'] },
    { id: 'product', label: 'Product', options: ['Product-A', 'Product-B', 'Product-C'] },
    { id: 'standard', label: 'Standard', options: ['Standard', 'Custom'] },
    { id: 'planType', label: 'Plan Type', options: ['Type-A', 'Type-B', 'Type-C'] }
  ];

  function clearSearch() {
    setSearch(DEFAULT_SEARCH);
  }

  return (
    <div className="h-screen w-screen overflow-hidden bg-white">
      <div className="flex h-full flex-col">
        {/* Header */}
        <header className="shrink-0 px-5 sm:px-6 lg:px-8 py-4 border-b border-slate-200 bg-white">
          <div className="flex items-center gap-3">
            <Icon icon="mdi:briefcase-outline" className="text-2xl" style={{ color: BRAND }} />
            <div>
              <h1 className="text-xl sm:text-2xl font-semibold text-slate-800">Portfolio Management</h1>
            </div>
          </div>
        </header>

        {/* Main */}
        <main className="flex-1 min-h-0 flex flex-col">
          <TabView
            className="flex-1 min-h-0 flex flex-col"
            pt={{
              panelContainer: { className: 'flex-1 min-h-0 flex flex-col px-5 sm:px-6 lg:px-8 py-5' },
              nav: { className: 'px-5 sm:px-6 lg:px-8 pt-3 bg-white border-b border-slate-200' },
              inkbar: { className: 'bg-[#002677]' }
            }}
          >
            {/* Portfolio Management */}
            <TabPanel header="Portfolio Management" leftIcon="pi pi-briefcase mr-2">
              <div className="flex h-full min-h-0 flex-col gap-6">
                {/* Filters - styled like the screenshot */}
                <section className="shrink-0 rounded-xl border border-slate-200 bg-white shadow-sm">
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      console.log('Search form values:', search);
                    }}
                  >
                    <div className="p-5 sm:p-6">
                      {/* Grid: 4 per row on lg, 2 per row on sm/md, 1 per row on mobile */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                        {/* Plan Code (Input) */}
                        <div>
                          <div className="text-[11px] font-semibold text-slate-500 tracking-wide mb-1">Plan Code</div>
                          <InputText
                            id="planCode"
                            value={search.planCode}
                            onChange={(e) => setSearch({ ...search, planCode: e.target.value })}
                            className="w-full h-11 rounded-lg border-slate-300 bg-white px-4 text-[15px] placeholder:text-slate-400
                                       focus:border-[#002677] focus:ring-2 focus:ring-[#002677]/30"
                            placeholder="Plan Code"
                          />
                        </div>

                        {/* Dropdowns (Segment, State, COC Series, License, Product, Standard, Plan Type) */}
                        {FILTERS.map(({ id, label, options }) => (
                          <div key={id}>
                            <div className="text-[11px] font-semibold text-slate-500 tracking-wide mb-1">{label}</div>
                            <Dropdown
                              id={id}
                              value={(search as any)[id]}
                              onChange={(e) => setSearch({ ...search, [id]: e.value })}
                              options={options.map((o) => ({ label: o, value: o }))}
                              placeholder={label}
                              className="w-full"
                              pt={{
                                root: {
                                  className:
                                    'w-full rounded-lg border border-slate-300 bg-white shadow-sm focus-within:ring-2 ' +
                                    'focus-within:ring-[#002677]/30 focus-within:border-[#002677]'
                                },
                                label: {
                                  className:
                                    'min-h-[44px] leading-[44px] px-4 text-[15px] text-slate-700 placeholder:text-slate-400'
                                },
                                trigger: { className: 'h-11 w-11 text-slate-400' },
                                panel: { className: 'min-w-[16rem] rounded-lg shadow-lg ring-1 ring-slate-200' },
                                item: { className: 'text-[15px]' }
                              }}
                            />
                          </div>
                        ))}
                      </div>

                      {/* Buttons: Clear & Search as full-width outlined, side-by-side */}
                      <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <Button
                          type="button"
                          label="Clear"
                          size="large"
                          outlined
                          className="w-full !h-11 !rounded-md !font-semibold !text-[14px]
                                     !text-[#ea580c] !border-[#f59e0b] hover:!bg-orange-50"
                          onClick={clearSearch}
                        />
                        <Button
                          type="submit"
                          label="Search"
                          size="large"
                          outlined
                          className="w-full !h-11 !rounded-md !font-semibold !text-[14px]
                                     !text-[#002677] !border-[#002677] hover:!bg-[#002677]/10"
                        />
                      </div>
                    </div>
                  </form>
                </section>

                {/* Results */}
                <section className="flex-1 min-h-0 flex flex-col rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden">
                  <div className="shrink-0 p-3 sm:p-4 border-b border-slate-200 bg-slate-50/60 flex items-center justify-between">
                    <div className="text-sm text-slate-600">
                      {tableData.length} result{tableData.length !== 1 ? 's' : ''} found
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        label="Export"
                        icon="pi pi-download"
                        size="small"
                        outlined
                        className="!h-10 !px-3 !rounded-lg !text-[#002677] !border-[#002677] hover:!bg-[#002677]/10"
                      />
                    </div>
                  </div>

                  {/* Scrollable table region */}
                  <div className="flex-1 min-h-0 overflow-auto">
                    <Table
                      settings={tableSettings}
                      records={tableData}
                      loading={false}
                      totalRecords={tableData.length}
                      paginate
                      enableSort
                      pageSize={25}
                      rowsPerPage={[10, 25, 50]}
                      onPageChange={(e) => console.log('Page changed:', e)}
                    />
                  </div>

                  {tableData.length === 0 && (
                    <div className="p-10 text-center text-slate-500">No results. Adjust filters and try again.</div>
                  )}
                </section>
              </div>
            </TabPanel>

            {/* My Plans */}
            <TabPanel header="My Plans" leftIcon="pi pi-list mr-2">
              <div className="h-full flex flex-col">
                <div className="shrink-0 mb-4 flex items-center gap-2">
                  <Icon icon="mdi:clipboard-list-outline" className="text-2xl" style={{ color: BRAND }} />
                  <h2 className="text-xl font-semibold text-slate-800">My Plans</h2>
                </div>
                <div className="flex-1 min-h-0 overflow-auto rounded-xl border border-slate-200 bg-white shadow-sm p-6">
                  <MyPlans />
                </div>
              </div>
            </TabPanel>
          </TabView>
        </main>
      </div>
    </div>
  );
}

function MyPlans() {
  return <div className="text-slate-600">My Plans component is available as a dedicated route too.</div>;
}
