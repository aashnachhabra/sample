import { Accordion, AccordionTab } from 'primereact/accordion';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { useMemo, useState } from 'react';

export function Accumulators({ isMedical = true }: { isMedical?: boolean }) {
  const tableData = useMemo(() => ([
    { title: 'Deductible Type', isDropdown: true },
    { title: 'Out-of-Pocket Type', isDropdown: true },
    { title: 'Medical and Rx Deductibles Integrated', isDropdown: true },
    { title: 'Medical and Rx Out-of-Pocket Integrated', isDropdown: true },
    { title: 'Deductible - Individual', isDropdown: false },
    { title: 'Deductible - Family', isDropdown: false },
    { title: 'Out-of-Pocket - Individual', isDropdown: false },
    { title: 'Out-of-Pocket - Family', isDropdown: false },
    { title: 'Default Coinsurance', isDropdown: false },
    { title: 'Default Copay', isDropdown: false }
  ]), []);

  const rxTableData = useMemo(() => ([
    { title: 'Deductible - Individual', isDropdown: false },
    { title: 'Deductible - Family', isDropdown: false },
    { title: 'Out-of-Pocket - Individual', isDropdown: false },
    { title: 'Out-of-Pocket - Family', isDropdown: false }
  ]), []);

  const [selectedCity, setSelectedCity] = useState<string | null>(null);
  const cities = ['a', 'b', 'c'];
  const rows = isMedical ? tableData : rxTableData;

  return (
    <div className="w-full bg-white border border-slate-300 rounded-lg overflow-hidden">
      <Accordion multiple className="w-full">
        <AccordionTab header="Accumulators" selected className="text-slate-800 font-semibold text-[16px]">
          <div className="w-full px-6 py-4">
            <DataTable
              value={rows}
              className="w-full"
              scrollable
              scrollHeight="600px"
              tableStyle={{ minWidth: '100%' }}
            >
              <Column
                field="title"
                header=""
                body={(row) => (
                  <div className="text-[14px] text-slate-700 font-medium">{row.title}</div>
                )}
              />
              <Column
                header="Preferred"
                body={(row) =>
                  row.isDropdown ? (
                    <div className={`flex w-full ${isMedical ? 'col-span-3' : 'col-span-2'}`}>
                      <Dropdown
                        options={cities}
                        value={selectedCity}
                        onChange={(e) => setSelectedCity(e.value)}
                        className="w-full h-10 text-[14px] border border-slate-300 rounded-lg px-3"
                        placeholder="Select"
                      />
                    </div>
                  ) : (
                    <InputText
                      className="w-full h-10 text-[14px] border border-slate-300 rounded-lg px-3"
                      placeholder="Enter value"
                    />
                  )
                }
              />
              <Column
                header="Network"
                body={(row) =>
                  row.isDropdown ? (
                    <div className="hidden" />
                  ) : (
                    <InputText
                      className="w-full h-10 text-[14px] border border-slate-300 rounded-lg px-3"
                      placeholder="Enter value"
                    />
                  )
                }
              />
              {isMedical && (
                <Column
                  header="OON"
                  body={(row) =>
                    row.isDropdown ? (
                      <div className="hidden" />
                    ) : (
                      <InputText
                        className="w-full h-10 text-[14px] border border-slate-300 rounded-lg px-3"
                        placeholder="Enter value"
                      />
                    )
                  }
                />
              )}
            </DataTable>
          </div>
        </AccordionTab>
      </Accordion>
    </div>
  );
}
