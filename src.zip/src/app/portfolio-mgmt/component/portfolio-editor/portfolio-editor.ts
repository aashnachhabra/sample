import { Component } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-portfolio-editor',
  templateUrl: './portfolio-editor.html',
  styleUrl: './portfolio-editor.scss',
})
export class PortfolioEditor {
  constructor(private router: Router) {}
  isDBSViewOn: boolean = false;
  toggleDBSView() {
    this.isDBSViewOn = !this.isDBSViewOn;
    console.log("DBS View:", this.isDBSViewOn ? "ON" : "OFF");

    if (this.isDBSViewOn) {
      this.router.navigate(['/portfolio-management/dbs-view']);
    }
  }
  access_token = sessionStorage.getItem('access_token');

}
