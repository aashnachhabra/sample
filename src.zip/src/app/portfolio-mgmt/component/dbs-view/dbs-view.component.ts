import { Component } from '@angular/core';

@Component({
  selector: 'app-dbs-view',
  templateUrl: './dbs-view.component.html',
  styleUrls: ['./dbs-view.component.css']
})
export class DBSViewComponent {

}
